﻿namespace _05BirthdayCelebrations.Models
{
    public interface IBirthable
    {
        string Birthday { get; }
    }
}