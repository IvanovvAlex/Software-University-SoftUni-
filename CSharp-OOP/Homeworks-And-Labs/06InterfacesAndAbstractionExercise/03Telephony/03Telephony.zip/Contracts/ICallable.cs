﻿namespace _03Telephony
{
    public interface ICallable
    {
        string Call(string num);
    }
}