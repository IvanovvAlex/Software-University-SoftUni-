﻿namespace _03Telephony
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}