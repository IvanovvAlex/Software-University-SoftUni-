﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04BorderControl.Contracts
{
     public interface IInhabitant
    {      
         string Id { get;}
    }
}
